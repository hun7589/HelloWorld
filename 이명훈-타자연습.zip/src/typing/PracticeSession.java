package typing;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PracticeSession {

    public static void start(Connection conn, int userId, Scanner sc) {
        try {
            System.out.println("\n===== 연습 시작 =====");
            System.out.print("난이도 선택 (1: 초급, 2: 중급, 3: 고급)> ");
            String lvlChoice = sc.nextLine().trim();
            String level = switch (lvlChoice) {
                case "1" -> "초급";
                case "2" -> "중급";
                case "3" -> "고급";
                default  -> "초급";
            };

            System.out.print("언어 선택 (1: 한글, 2: 영어, 3: 일본어)> ");
            String langChoice = sc.nextLine().trim();
            String language = switch (langChoice) {
                case "1" -> "한글";
                case "2" -> "영어";
                case "3" -> "일본어";
                default  -> "한글";
            };

            // ================================
            // [초급 모드] 랜덤 30개 문제 풀기 (엔터 대기 없이 바로 입력)
            // ================================
            if (level.equals("초급")) {
                String fetch30RandomSql = ""
                    + "SELECT id, content "
                    + "FROM texts "
                    + "WHERE txt_level = ? AND txt_language = ? "
                    + "ORDER BY DBMS_RANDOM.VALUE "
                    + "FETCH FIRST 30 ROWS ONLY";

                List<Integer> textIds  = new ArrayList<>();
                List<String>  textList = new ArrayList<>();

                try (PreparedStatement pstmt = conn.prepareStatement(fetch30RandomSql)) {
                    pstmt.setString(1, level);
                    pstmt.setString(2, language);
                    try (ResultSet rs = pstmt.executeQuery()) {
                        while (rs.next()) {
                            textIds.add(rs.getInt("id"));
                            textList.add(rs.getString("content"));
                        }
                    }
                }

                if (textList.isEmpty()) {
                    System.out.println("초급 '" + language + "' 예문이 없습니다.");
                    return;
                }

                System.out.println("\n--- 초급 모드: 총 " + textList.size() + "개의 예문이 랜덤으로 로드되었습니다 ---");

                double totalAccuracy = 0.0;

                for (int idx = 0; idx < textList.size(); idx++) {
                    int textId      = textIds.get(idx);
                    String original = textList.get(idx);

                    System.out.println("\n[" + (idx + 1) + "/" + textList.size() + "] 문장:");
                    System.out.println(original);
                    System.out.println("--------------------------------");
                    System.out.print("바로 입력하세요> ");

                    long startTime = System.currentTimeMillis();
                    String typed   = sc.nextLine();
                    long endTime   = System.currentTimeMillis();

                    double elapsedSeconds = (endTime - startTime) / 1000.0;
                    int typedChars        = typed.length();
                    double speed          = TypingUtils.calculateSpeed(typedChars, elapsedSeconds);
                    double accuracy       = TypingUtils.calculateAccuracy(original, typed);

                    totalAccuracy += accuracy;

                    System.out.printf(
                        "[%d] 결과: 속도 = %.2f WPM, 정확도 = %.2f%%%n",
                        (idx + 1), speed, accuracy
                    );

                    String insertSql = ""
                        + "INSERT INTO results (user_id, text_id, speed, accuracy) "
                        + "VALUES (?, ?, ?, ?)";
                    try (PreparedStatement pstmt2 = conn.prepareStatement(insertSql)) {
                        pstmt2.setInt   (1, userId);
                        pstmt2.setInt   (2, textId);
                        pstmt2.setDouble(3, speed);
                        pstmt2.setDouble(4, accuracy);
                        pstmt2.executeUpdate();
                    }
                    System.out.println("→ 결과가 저장되었습니다.");
                }

                double avgAccuracy = totalAccuracy / textList.size();
                System.out.printf("\n[초급 모드 완료] 평균 정확도 = %.2f%%%n", avgAccuracy);
                return;
            }

            // ================================
            // [중급 모드] 랜덤 20개 문제 풀기 (엔터 대기 없이 바로 입력)
            // ================================
            if (level.equals("중급")) {
                String fetch20RandomSql = ""
                    + "SELECT id, content "
                    + "FROM texts "
                    + "WHERE txt_level = ? AND txt_language = ? "
                    + "ORDER BY DBMS_RANDOM.VALUE "
                    + "FETCH FIRST 20 ROWS ONLY";

                List<Integer> textIds   = new ArrayList<>();
                List<String>  textList  = new ArrayList<>();

                try (PreparedStatement pstmt = conn.prepareStatement(fetch20RandomSql)) {
                    pstmt.setString(1, level);
                    pstmt.setString(2, language);
                    try (ResultSet rs = pstmt.executeQuery()) {
                        while (rs.next()) {
                            textIds.add(rs.getInt("id"));
                            textList.add(rs.getString("content"));
                        }
                    }
                }

                if (textList.isEmpty()) {
                    System.out.println("중급 '" + language + "' 예문이 없습니다.");
                    return;
                }

                System.out.println("\n--- 중급 모드: 총 " + textList.size() + "개의 예문이 랜덤으로 로드되었습니다 ---");

                double totalAccuracy = 0.0;

                for (int idx = 0; idx < textList.size(); idx++) {
                    int textId      = textIds.get(idx);
                    String original = textList.get(idx);

                    System.out.println("\n[" + (idx + 1) + "/" + textList.size() + "] 문장:");
                    System.out.println(original);
                    System.out.println("--------------------------------");
                    System.out.print("바로 입력하세요> ");

                    long startTime = System.currentTimeMillis();
                    String typed   = sc.nextLine();
                    long endTime   = System.currentTimeMillis();

                    double elapsedSeconds = (endTime - startTime) / 1000.0;
                    int typedChars        = typed.length();
                    double speed          = TypingUtils.calculateSpeed(typedChars, elapsedSeconds);
                    double accuracy       = TypingUtils.calculateAccuracy(original, typed);

                    totalAccuracy += accuracy;

                    System.out.printf(
                        "[%d] 결과: 속도 = %.2f WPM, 정확도 = %.2f%%%n",
                        (idx + 1), speed, accuracy
                    );

                    String insertSql = ""
                        + "INSERT INTO results (user_id, text_id, speed, accuracy) "
                        + "VALUES (?, ?, ?, ?)";
                    try (PreparedStatement pstmt2 = conn.prepareStatement(insertSql)) {
                        pstmt2.setInt   (1, userId);
                        pstmt2.setInt   (2, textId);
                        pstmt2.setDouble(3, speed);
                        pstmt2.setDouble(4, accuracy);
                        pstmt2.executeUpdate();
                    }
                    System.out.println("→ 결과가 저장되었습니다.");
                }

                double avgAccuracy = totalAccuracy / textList.size();
                System.out.printf("\n[중급 모드 완료] 평균 정확도 = %.2f%%%n", avgAccuracy);
                return;
            }

            // ================================
            // [고급 모드] 문장별로 잘라서 순차 입력 (엔터 대기 없이 바로 입력)
            // ================================
            // 1) 랜덤으로 한 개의 긴 글(text_id, content)을 가져온다
            String textSql = ""
                + "SELECT id, content "
                + "FROM texts "
                + "WHERE txt_level = ? AND txt_language = ? "
                + "ORDER BY DBMS_RANDOM.VALUE "
                + "FETCH FIRST 1 ROWS ONLY";
            int textId = -1;
            String originalText = "";

            try (PreparedStatement pstmt = conn.prepareStatement(textSql)) {
                pstmt.setString(1, level);
                pstmt.setString(2, language);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        textId = rs.getInt("id");
                        originalText = rs.getString("content");
                    }
                }
            }

            if (textId == -1) {
                System.out.println("해당 조건에 맞는 문제가 없습니다.");
                return;
            }

            // 2) 긴 글을 “문장 단위”로 분리
            String[] sentences = originalText.split("(?<=[\\.\\!\\?]|[。！？])\\s*");
            List<String> sentenceList = new ArrayList<>();
            for (String s : sentences) {
                s = s.trim();
                if (!s.isEmpty()) {
                    sentenceList.add(s);
                }
            }
            if (sentenceList.isEmpty()) {
                sentenceList.add(originalText.trim());
            }

            System.out.println("\n--- 고급 모드: 총 " + sentenceList.size() + "개의 문장으로 나뉘어 로드되었습니다 ---");

            double totalAccuracy = 0.0;

            // 3) 각 문장을 차례로 보여주고, 입력→측정→DB에 저장
            for (int idx = 0; idx < sentenceList.size(); idx++) {
                String sentence = sentenceList.get(idx);

                System.out.println("\n[" + (idx + 1) + "/" + sentenceList.size() + "] 문장:");
                System.out.println(sentence);
                System.out.println("--------------------------------");
                System.out.print("바로 입력하세요> ");

                long startTime = System.currentTimeMillis();
                String typed   = sc.nextLine();
                long endTime   = System.currentTimeMillis();

                double elapsedSeconds = (endTime - startTime) / 1000.0;
                int typedChars        = typed.length();
                double speed          = TypingUtils.calculateSpeed(typedChars, elapsedSeconds);
                double accuracy       = TypingUtils.calculateAccuracy(sentence, typed);

                totalAccuracy += accuracy;

                System.out.printf(
                    "[%d] 결과: 속도 = %.2f WPM, 정확도 = %.2f%%%n",
                    (idx + 1), speed, accuracy
                );

                String insertSql = ""
                    + "INSERT INTO results (user_id, text_id, speed, accuracy) "
                    + "VALUES (?, ?, ?, ?)";
                try (PreparedStatement pstmt2 = conn.prepareStatement(insertSql)) {
                    pstmt2.setInt   (1, userId);
                    pstmt2.setInt   (2, textId);
                    pstmt2.setDouble(3, speed);
                    pstmt2.setDouble(4, accuracy);
                    pstmt2.executeUpdate();
                }
                System.out.println("→ 결과가 저장되었습니다.");
            }

            double avgAccuracy = totalAccuracy / sentenceList.size();
            System.out.printf("\n[고급 모드 완료] 평균 정확도 = %.2f%%%n", avgAccuracy);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
